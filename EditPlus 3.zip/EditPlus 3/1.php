<?php
	eco "你好";

?>

<!doctype html>
<html >
 <head>
  <meta charset="UTF-8">
  <title>Document</title>
	<style>
		
	</style>
 </head>
 <body>
	<h1 sfsfafsfsfafsafsaf </h1>
	<script>
		function xxx(){
		
		}
		xxx();
	
	</script>
 </body>
</html>
